# Support me I need your support now please ❤️

[![](https://img.shields.io/badge/Paypal-Support%20Me-blue)](https://www.paypal.me/Hadikob)
# Discord bots website template
Stunning website with good UI design for the new Discord bots, built with Bootstrap and has many ready-made pages to edit by your own.

# v.2
In this version, many things have been changed on the site to make it more wonderful and easy to use.
* You can get the old version of the site, you can find it in ``master branch``.

## main page:

![Screenshot1](https://raw.githubusercontent.com/Hadi-Koubeissi/Discord-bot-website-template/Main/assets/Screenshot.PNG)

## command page:
![Screenshot4](https://raw.githubusercontent.com/Hadi-Koubeissi/Discord-bot-website-template/Main/assets/Screen2.PNG)

and more pages...

# Installing
Download or fork the repo

`git clone https://github.com/Hadi-Koubeissi/Discord-bot-website-template`

open index.html with any code editor and edit the name or logo and then have fun.

## Built With: 

* [Bootstrap](https://getbootstrap.com/) - The web framework used
* [Jquery](https://jquery.com/) - For scripts

## Authors

[Hadi-Koubeissi](https://github.com/Hadi-Koubeissi)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details
